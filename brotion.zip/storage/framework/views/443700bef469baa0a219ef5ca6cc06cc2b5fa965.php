
<?php $__env->startSection('content'); ?>

<div class="main-content">
        <section class="section">
          <div class="section-header">
						<div class="row">
							<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
								<div class="section-header-breadcrumb-content">
									<h1>City List</h1>
								</div>
							</div>
							<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
								<div class="section-header-breadcrumb-chart float-right">
								</div>
							</div>
						</div>
          </div>

         <div class="row mb-3">
          <div class="col-lg-12 ">
            <a href="<?php echo e(route('admin-add-new-city')); ?>" class="btn btn-primary" style="float:right;">Add New City</a>

          </div>
           
         </div>

          <div class="row">
              
              <div class="col-12 col-md-12 col-lg-12">
                <div class="card">
                  <div class="card-header">
                    <h4></h4>
                  </div>
                  <div class="card-body">
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th scope="col">#</th>
                          <th scope="col">Province Name</th>
                          <th scope="col">City Name</th>
                          <th scope="col">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $i=1
                        ?>
                        <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($i++); ?></td>
                          <td><?php echo e(isset($c->province)?$c->province->name:''); ?></td>
                          <td><?php echo e($c->name); ?></td>
                          <td>
                            <a href="<?php echo e(route('admin-city-edit',['id'=>$c->id])); ?>" class="btn btn-primary">Edit</a>
                            <a href="<?php echo e(route('admin-city-delete',['id'=>$c->id])); ?>" class="btn btn-dark">Delete</a>
                          </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                      
                      
                      
                      
                    </table>
                    <?php echo e($city->links()); ?>

                    
                  </div>
                </div>
                
                
              </div>
             
            </div>

      </section>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.partials.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\brotion\resources\views/admin/city_list.blade.php ENDPATH**/ ?>