<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/css/style.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://kit.fontawesome.com/f46361531e.js" crossorigin="anonymous"></script>
    <title>HomePage</title>
    <style type="text/css">
    </style>
  </head>
  <body style="width: 100%;">
    <section class="mb-5 coverImage">
      <?php echo $__env->make('frontendtemplate.navbarn', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      
       <div class="container mt-3" id="alert">
                  <div class="row">
                      <div class="col-lg-2">
                          
                      </div>
                      <div class="col-lg-8">
                           <div style="text-align: center;" id="error">
                         <?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <?php endif; ?>
                      </div>
                      </div>
                      <div class="col-lg-2">
                          
                      </div>
                     
                  </div>
             </div> 
      
      
                  
          

      <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-6d-block outer-wrapper-main">
          
          <h1 class="text-white main-heading">We show you the market</h1>
          <p class="text-white d-inline d-block"><span> publishing and graphic design, Lorem ipsum is a placeholder
            text commonly used to demonstrate the visual form of a document
          or a typeface without </span></p>
          <button  class="btn btn-primary btnarena">Open Opportunities</button>
          <img class="img-fluid p-2" src="<?php echo e(asset('asset/images/Icon ionic-ios-play-circle.png')); ?>">
          
        </div>
        <?php if(!Auth::check()): ?>
        <div class="col-lg-6 col-md-6 col-sm-6 pt-3 pl-5d-block card-left-postion">
          <div class="card card_set login-card-width">
            <div class="card-body ">
              <form method="Post" action="<?php echo e(route('login-post')); ?>">
                <?php echo csrf_field(); ?>
                <h5 class=" text-primary  pt-3 mr-4">Login Now</h5>
                <div class="form-group pt-3 ">
                  <input type="email" name="email" class="form-control text-primary fields" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Email">
                </div>
                <div class="form-group pt-3 pb-3  ">
                  <input type="password" name="password" class="form-control text-primary fields" id="exampleInputPassword1" placeholder="Password">
                </div>
                <button type="submit" class="btn btn-primary btn-lg btn-block mt-3 create-tender">Login</button>
              </form>
              <div class="row pt-3  pb-3">
                <div class="col-lg-8 col-md-8 col-sm-8 col-8 d-block text-dark do-you-account ">
                  <p class="do-have-account">Don't have Account?</p>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4 col-4 d-block text-primary signup">
                  <a href="<?php echo e(route('register')); ?>" class="signup-font">Sign up</a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <?php endif; ?>
      </div>
      
    </section>
    <section class=" ">
      <div class="container ">
        <div class="row ">
          <div class="col-6  col-xl-6 col-lg-6 col-md-4 col-sm-12 col-12 " style="">
            <h3 class="text-primary seacrh-find-opp">
            Search and Find Opprotunities
            </h3>
          </div>
          <div class="col-6 col-xl-6 col-lg-6 col-md-8 col-sm-12 col-12 ">
            <div class="Rectangle-12 row" >
              <div class="col-6 col-md-6 col-sm-6 col-6 mt-2 ">
                <span class="Search-by-location ">
                  Search by location
                </span>
              </div>
              <div class="col-6 col-md-6 col-sm-6  col-6 pt-1  justify-content-center text-center">
                <div class="Rectangle-13">
                  <span class="Find-Oppotunities pt-1">
                    Find Oppotunities
                    <i class="fa-solid fa-magnifying-glass"></i>
                    <img class="img-fluid search-icon" src="<?php echo e(asset('asset/images/Icon feather-search.png')); ?> " height="20px" width="20px">
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="  justify-content-center ">
      <div class="container">
        <div class="row ">
          <div class="col-xl-8 col-lg-8 col-md-8 col-sm-12 mb-3 pb-5">
            <h1 class="mt-5 heading-how-does">How <strong>does it work?</strong> </h1>
            <p class="justify-content-center d-inline d-block"> The parsa platform is a link between the supplier and the buyer, enabling small and medium enterprises to view and submit quotations electricity in government and private sector purchases.It also enables small and medium enterprise tosubmit request for   quotation among themselve.</p>
          </div>
          <div class="col-lg-4 col-md-4 col-sm-6  pr-1 pl-5 pt-5 set justify-content-center text-center ">
            <div class="Rectangle-14 pt-1  ">
              <span class="See-more-Opportunities ">
                See more Opportunities
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section>
      <div class="container justify-content-center text-center">
        <div class="row" style="text-align: -webkit-center;">
          <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 mb-3 text-center p-2 color">
            <div class="card text-center card-setting bg-white">
              <div class="card-body">
                <div class=" mb-3 mt-3">
                  <img src="<?php echo e(asset('asset/images/Group 16928.png')); ?>">
                </div>
                <div class="col-lg-12" style="margin-top: 2rem;">
                  <h2><strong> Register Yourself</strong></h2>
                </div>
                <div class="col-lg-12">
                  <p>  In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.</p>
                  <a href="#"><u>Learn More</u></a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 mb-3 text-center color" style="padding: 0.5rem;">
            <div class="card-hover">
              <div class=" text-center /">
                <div class="col-lg-12 mb-3 mt-3">
                  <img src="<?php echo e(asset('asset/images/Group 16929.png')); ?>">
                </div>
                <div class="col-lg-12" style="margin-top: 2rem; font-family: OpenSans;">
                  <h3><strong>  Make Tenders </strong></h3>
                </div>
                <div class="col-lg-12" style=" font-family: OpenSans;">
                  <p> In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.</p>
                </div>
                <a href="#"><u>Learn More</u></a>
              </div>
            </div>
            
          </div>
          <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 mb-3 text-center color" style="padding: 0.5rem;">
            <div class="card-hover">
              <div class="text-center ">
                <div class="col-lg-12 mb-3 mt-3">
                  <img src="<?php echo e(asset('asset/images/Group 16930.png')); ?>">
                </div>
                <div class="col-lg-12" style="margin-top: 2rem; font-family: OpenSans;">
                  <h3><strong>  Make Bids </strong></h3>
                </div>
                <div class="col-lg-12"style=" font-family: OpenSans;">
                  <p> In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.</p>
                </div>
                <a href="#"><u>Learn More</u> </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section style="margin-top:5rem;margin-bottom: 5rem; " class=" text-center ">
      <div class="  middle-image  text-white ">
        <div class="container justify-content-center text-center pt-5">
          <h1 class="text-center pt-2 text-white  ">Auto Procure Summary </h1>
          <div class="row  pt-5 justify-content-center text-center">
            <div class="col-lg-4 col-md-4 col-sm-12 col-12 pb-4 ">
              <div class="Rectangle-904" >
                <img class ="img-fluid pt-3 auto-procure-image"src="<?php echo e(asset('asset/images/users.png')); ?>">
                <p class="pt-2">
                  1000
                </p>
                <h5 class=" text-white pt-3">
                USERS
                </h5>
              </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-12 pb-4  ">
              <div class="Rectangle-904" >
                <img  class ="img-fluid pt-3 auto-procure-image" src="<?php echo e(asset('asset/images/shield-fill-check.png')); ?>">
                <p class="pt-2">
                  500
                </p>
                <h5 class=" text-white pt-3">
                TENDERS
                </h5>
              </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-12 pb-4   ">
              <div class="Rectangle-904" >
                <img  class ="img-fluid pt-3 auto-procure-image" src="<?php echo e(asset('asset/images/Icon ionic-logo-buffer.png')); ?>">
                <p class="pt-2">
                  500
                </p>
                <h5 class="text-white pt-3">
                BIDS
                </h5>
              </div>
            </div>
          </div>
        </div>
        <a href="#" class="btn btn-primary btn-lg mt-5 mb-3 create-tender">Create Tender</a>
      </div>
    </section>
    
    <section >
      <div class="container">
        <div class="row">
          <div class="col-lg-8 col-md-12 col-sm-12 col-12 about-us-padding">
            <h2 class="About-Us">
            About Us
            </h2>
            <p class="pt-3 d-inline d-block">
              In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.
              <br><br>
              In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.
            </p>
            <a class="btn btn-primary btn-lg mt-5 create-tender">Create Tender</a>
          </div>
          <div class="col-lg-4 col-md-12 col-sm-12 col-12 middle-image2 mb-3 justify-content-center text-center" style="margin-left: 0px !important;display: flex;align-items: center; ">
            <div class="pt-5 pb-5">
              <img  class ="img-fluid pt-5" src="<?php echo e(asset('asset/images/Group 4.png')); ?>" style="width:50%;margin-top: 40%;">
            </div>
          </div>
        </div>
      </div>
    </section>
    
    
    
  <section class="pt-2 "></section>
  <section class="pt-5  ">
    <div class="container ">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-12">
          <p>Trusted by</p>
          <h2 class="people-all">
          People All Around Saudi Araibia </h2>
        </div>
      </div>
      <div class="row ">
        <div class="col-lg-6 col-md-12 col-sm-12 col-12 pt-3">
          <div class="Rectangle-16">
            <div class="row pt-3  ">
              <div class="d-flex flex-row">
                <div class="p-2"> <img src="<?php echo e(asset('asset/images/Group 16945.png')); ?>"   class="rounded-circle img-fluid">
                </div>
                <div class="p-2"><h5>Adam Johns<h5></div>
              </div>
            </div>
            <div class="col-12 pt-2">
              <p class="">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before the final copy is</p>
            </div>
          </div>
        </div>
        <div class="col-lg-6 col-md-12 col-sm-12 col-12 pt-3">
          <div class="Rectangle-16">
            <div class="row pt-3  ">
              <div class="d-flex flex-row">
                <div class="p-2"> <img src="<?php echo e(asset('asset/images/Group 16945.png')); ?>"   class="rounded-circle img-fluid">
                </div>
                <div class="p-2"><h5>Adam Johns<h5></div>
              </div>
            </div>
            <div class="col-12 pt-2">
              <p class="">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before the final copy is</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <?php echo $__env->make('frontendtemplate.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
  <script type="text/javascript">
  var clicks = 0;
  function clickME() {
  clicks += 1;
  document.getElementById("clicks").innerHTML = clicks;
  }
  </script>
  <script type="text/javascript">
    setTimeout(function () {
      $('#alert').slideUp();
    },4000);
  </script>
</body>
</html><?php /**PATH F:\xampp\htdocs\brotion\resources\views/welcome.blade.php ENDPATH**/ ?>