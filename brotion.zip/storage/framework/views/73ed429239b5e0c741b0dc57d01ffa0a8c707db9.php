
<?php $__env->startSection('content'); ?>

<div class="main-content">
        <section class="section">
          <div class="section-header">
						<div class="row">
							<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
								<div class="section-header-breadcrumb-content">
									<h1>User List</h1>
								</div>
							</div>
							<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
								<div class="section-header-breadcrumb-chart float-right">
									
								
									
								</div>
							</div>
						</div>
          </div>



          <div class="row">
              
              <div class="col-12 col-md-12 col-lg-12">
                <div class="card">
                  <div class="card-header">
                    <h4></h4>
                  </div>
                  <div class="card-body">
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th scope="col">#</th>
                          <th scope="col">Role</th>
                          <th scope="col">Name</th>
                          <th scope="col" style="width:17%;">Login Status</th>
                          <th scope="col">Email</th>
                          <th scope="col">Phone</th>
                          <th scope="col">Address</th>
                          <th scope="col">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                      	<?php $i=1
                      	?>
                      	<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      	<tr>
                      		<td><?php echo e($i++); ?></td>
                      		<td><?php echo e(ucwords($u->role)); ?></td>
                      		<td><?php echo e($u->name); ?></td>
                      		<td><?php if($u->login_status=='1'): ?><button class="btn btn-primary" style="width:108%">Approved Account</button><?php elseif($u->login_status=='0'): ?><button>Pending Account</button>
                          <?php endif; ?>
                      		</td>
                      		<td><?php echo e($u->email); ?></td>
                      		<td><?php echo e($u->phone); ?></td>
                      		<td><?php echo e($u->address); ?></td>
                      		<td><a href="<?php echo e(route('user-delete',['id'=>$u->id,'role'=>$u->role])); ?>" class="btn btn-dark">Delete</a></td>
                      	</tr>
                      	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        
                        
                      </tbody>
                    </table>
                    <?php echo e($user->links()); ?>

                  </div>
                </div>
                
                
              </div>
             
            </div>

      </section>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.partials.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/r0mm6f8xfmww/public_html/resources/views/admin/adminhome.blade.php ENDPATH**/ ?>