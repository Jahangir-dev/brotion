<section>
      <div class="topnav">
        <div style="float: left;">
          
          <div class="dropdown">
            <span>Language</span>
            <div class="dropdown-content">
              <div><a>English</a></div>
              <div> <a>Arabic</a></div>
              
            </div>
          </div>
        </div>
        
        
        <?php if(Auth::check()): ?>
        <div class="dropdown" style="float:right;">
            <span><i class="fa fa-user" style="margin-right: 10px;"></i><?php echo e(Auth::user()->name); ?></span>
            <div class="dropdown-content" style="margin-left:-35px">
              <div><a href="<?php echo e(route('user-business')); ?>">Profile</a></div>
              <div> <a href="<?php echo e(route('opportunity-management')); ?>">My Tender</a></div>
              <div> <a href="<?php echo e(route('bid-management')); ?>">My Bids</a></div>
              <div> <a href="<?php echo e(route('logout')); ?>">Logout</a></div>
              
            </div>
          </div>
        <a href="#"><i class="fa fa-bell icon" ></i></a>
        <?php else: ?>
        <a href="<?php echo e(route('register')); ?>">Join Us</a>
        <a href="<?php echo e(route('login')); ?>">Login</a>
        <?php endif; ?>
      </div>
    </section><?php /**PATH /home/r0mm6f8xfmww/staging.brotions.com/resources/views/frontendtemplate/topnavbar.blade.php ENDPATH**/ ?>