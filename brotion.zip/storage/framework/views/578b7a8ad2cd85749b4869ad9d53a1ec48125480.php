<style type="text/css">

.dropdown-toggle::after {
    display: inline-block;
    font-size: 20px;
    color: white;
    width: 0;
    height: 0;
    margin-left: 0.255em;
    vertical-align: 0.255em;
    content: "";
    border-top: 0.3em solid;
    border-right: 0.3em solid transparent;
    border-bottom: 0;
    border-left: 0.3em solid transparent;
}
.nav-width{
justify-content: space-evenly;
width: 38%;
margin-left: 80px;
}

@media  only screen and (max-width: 1024px) {


.nav-width {
    justify-content: space-evenly!important;
    width: 60%!important;
    margin-left: 15px!important;
}
}


@media  only screen and (max-width: 768px) {


.nav-width {
    justify-content: space-evenly!important;
    width: 60%!important;
    margin-left: 15px!important;
}
}

</style>
<section class="box-shadow">

    <div class="m-4" style="margin-top:0px !important">
      <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid">
          <a href="#" class="navbar-brand"><img src="<?php echo e(asset('asset/images/newlogo.png')); ?>" class="logo"></a>
          <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
          <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse "  id="navbarCollapse">
            <div class="navbar-nav nav-width ">
              <a href="<?php echo e(route('welcome')); ?>" class="nav-item nav-link text-white active">Home</a>
              <a href="<?php echo e(route('market-place')); ?>" class="nav-item nav-link text-white">Marketplace</a>
          <?php if(Auth::check()): ?>
              <a href="<?php echo e(route('bid-management')); ?>" class="nav-item nav-link text-white">My Bids</a>
              <a href="<?php echo e(route('opportunity-management')); ?>" class="nav-item nav-link text-white" tabindex="-1">My Tender</a>
          <?php endif; ?>
            </div>
            <div class="navbar-nav ms-auto" style="margin-left: auto!important;">

             <?php if(Auth::check()): ?>
              <div class="dropdown">
                <a href="#" class="dropdown-toggle" data-bs-toggle="dropdown"><img style="width: 20px;" class="img-fluid" src="<?php echo e(asset('asset/images/Icon awesome-user-alt.png')); ?>"></a>
                <div class="dropdown-menu">
                    <a href="<?php echo e(route('user-business')); ?>" class="dropdown-item">Profile</a>
                    <a href="<?php echo e(route('logout')); ?>" class="dropdown-item">Logout</a>
                </div>
              </div>
            <?php else: ?>

              <div class="dropdown">
                <a href="#" class="dropdown-toggle" data-bs-toggle="dropdown"><img style="width: 20px;" class="img-fluid" src="<?php echo e(asset('asset/images/Icon awesome-user-alt.png')); ?>"></a>
                <div class="dropdown-menu">
                    <a href="<?php echo e(route('register')); ?>" class="dropdown-item">Join Us</a>
                    <a href="<?php echo e(route('welcome')); ?>" class="dropdown-item">Login</a>
                </div>
              </div>

            <?php endif; ?>

            </div>
          </div>
        </div>
      </nav>
    </div>

</section>
<?php /**PATH F:\xampp\htdocs\brotion\resources\views/frontendtemplate/navbarn.blade.php ENDPATH**/ ?>