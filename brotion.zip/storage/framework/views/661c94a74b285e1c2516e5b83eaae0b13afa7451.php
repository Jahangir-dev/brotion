
<?php $__env->startSection('content'); ?>

<div class="main-content">
        <section class="section">
          <div class="section-header">
						<div class="row">
							<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
								<div class="section-header-breadcrumb-content">
									<h1>Province List</h1>
								</div>
							</div>
							<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
								<div class="section-header-breadcrumb-chart float-right">
								</div>
							</div>
						</div>
          </div>

         <div class="row mb-3">
          <div class="col-lg-12 ">
            <a href="<?php echo e(route('add-new-province')); ?>" class="btn btn-primary" style="float:right;">Add New Province</a>

          </div>
           
         </div>

          <div class="row">
              
              <div class="col-12 col-md-12 col-lg-12">
                <div class="card">
                  <div class="card-header">
                    <h4></h4>
                  </div>
                  <div class="card-body">
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th scope="col">#</th>
                          <th scope="col">Province Name</th>
                          <th scope="col">Action</th>
                        </tr>
                      </thead>
                      <?php $i=1
                      ?>
                      <tbody>
                      	<?php $__currentLoopData = $province_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      	<tr>
                      		<td><?php echo e($i++); ?></td>
                      		<td><?php echo e($p->name); ?></td>
                      		<td><a href="<?php echo e(route('province-edit',['id'=>$p->id])); ?>" class="btn btn-primary" style="margin-right:10px">Edit</a>
                        <a href="<?php echo e(route('province-delete',['id'=>$p->id])); ?>" class="btn btn-dark">Delete</a></td>
                      	</tr>
                      	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                      
                      
                      
                      
                    </table>
                    
                    
                  </div>
                </div>
                
                
              </div>
             
            </div>

      </section>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.partials.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/r0mm6f8xfmww/public_html/resources/views/admin/province_list.blade.php ENDPATH**/ ?>