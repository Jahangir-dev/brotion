<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/css/add_new_opportunity_form.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>New Opportunity Mangement Form</title>
    <style type="text/css">
      .box{
        display: none;


    }
    </style>
  </head>
  <body>
    
         
    <?php echo $__env->make('frontendtemplate.topnavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php echo $__env->make('frontendtemplate.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class=" mb-5">
      <div class="background-image">
        <div class="row">
          <div class="col-lg-12">
            <h1 class="opp-management"><strong>Opportunity Management</strong></h1>
          </div>
          <div class="col-lg-12 text-center">
            <h3 class="do-you-need">Do you need any assistnace? You can now <br> contact us any time</h3>
          </div>
          
        </div>
      </div>
    </section>
    <section class="mt-3">
      <div class="container">
        <div class="row">
          
          <div class="col-lg-8 col-md-12 col-sm-12 mb-3">
            <h1 class="bottomh1">Opportunity <strong>Management</strong> </h1>
          </div>
          
        </div>
        
        
      </div>
      
    </section>
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
       <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>   
        </div>
        
      </div>
    </div>
    
    <section class="mt-5">
      <form method="post" action="<?php echo e(route('user-opportunity-save')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="opp_type" value="<?php echo e($type); ?>">
      <div class="container d-flex justify-content-center">
        <div class="col-12 col-offset-2">
          
          <div class="card mt-3">
            <!--  <div class="card-header font-weight-bold">General Step</div> -->
            <div class="card-body step">
              <div class="card-header font-weight-bold" style="background-color:#dfdfdf">
                <i class="fa fa-step-forward" style="margin-right:10px"></i><strong>Step</strong>
                <div>
                  <label >General Step</label>
                </div>
              </div>
              <div class="radio-group row justify-content-between px-3 text-center" style="justify-content:center !important">
                <div class="col-auto me-sm-2 mx-1 card-block py-0 text-center radio" style="margin-top:20px">
                  <div class="opt-icon"><i class="fa fa-user-plus" style="font-size: 70px; margin-left: 25px;"></i></div>
                  <p><b>Add New Opportunity</b></p>
                </div>
                
              </div>
            </div>
            
            <div id="userinfo" class="card-body p-4 step" style="display: none">
              <div class="card-header font-weight-bold" style="background-color:#dfdfdf">
                <i class="fa fa-step-forward" style="margin-right:10px"></i><strong>Step 1</strong>
                <div>
                  <label >General Information</label>
                </div>
              </div>
              <div class="mb-3">
                <h5 class="card-title font-weight-bold" style="margin-top:20px;color:#519bfd;">General Information</h5>
              </div>
              <div class="form-group row mb-3">
                <div class="col-lg-2">
                  
                </div>
                <div class="col-lg-6 col-md-12">
                  <label for="opp_title">Opportunity Title<b style="color: #dc3545;">*</b></label>
                  <input type="text" name="opp_title" class="form-control" id="opp_title" required>
                  <div class="invalid-feedback">This field is required</div>
                </div>
                
              </div>
              <div class="form-group row mb-3">
                <div class="col-lg-2">
                  
                </div>
                <div class="col-lg-6 col-md-12">
                  <label for="internal_reference">Internal Reference Number<b style="color: #dc3545;">*</b></label>
                  <input type="text" name="internal_reference" class="form-control" id="internal_reference" required>
                  <div class="invalid-feedback">This field is required</div>
                </div>
                
              </div>
              <div class="form-group row mb-3">
                <div class="col-lg-2">
                  
                </div>
                <div class="col-lg-6 col-md-12">
                  <label for="due_date">Due Date<b style="color: #dc3545;">*</b></label>
                  <input type="date" name="due_date" class="form-control due_date_validation" id="due_date" required>
                  <div class="invalid-feedback">This field is required</div>
                </div>
                
              </div>



              
            
              <?php if($type=="SmallValue"): ?>
              <div class="form-group row mb-3">
          <div class="row">
            <div class="col-lg-2">
              
            </div>
            <div class="col-lg-10">
              <div>
                <label><input type="radio" name="general_radio" value="bid_limit_radio"> Bid Limits</label>
                <label><input type="radio" name="general_radio" value="urgent_opportunity"> Urgent opportunity</label>
              </div>
            </div>
            
          </div>
        
        
        <div class="bid_limit_radio box">
          <div class="row mt-3">
            <div class="col-lg-2">
              
            </div>
            <div class="col-lg-6 col-md-12 col-sm-12 ">
              <label for="bid_limit">Bid Limit<b style="color: #dc3545;">*</b></label>
              <input type="number" name="bid_limit" class="form-control" id="bid_limit" >
            </div>
          </div>
          
        </div>
        <div class="row">
          <div class="col-lg-2">
            
          </div>
          <div class="col-lg-6 col-md-12 col-sm-12 mt-3">
                  <label for="day_to_deliver">Days to Deliver<b style="color: #dc3545;">*</b></label>
                  <input type="text" name="day_to_deliver" class="form-control" id="day_to_deliver" required>
                  <div class="invalid-feedback">This field is required</div>
             <div class="col-lg-12 col-md-12 col-sm-12 mt-3">
                  <label for="payment_day">Payment Days<b style="color: #dc3545;">*</b></label>
                  <input type="text" name="payment_day" class="form-control" id="payment_day" required>
                  <div class="invalid-feedback">This field is required</div>
                </div>   </div>
        </div>
              
                
              
                
              </div>


              
              <?php endif; ?>
            </div>
            <div  class="card-body p-5 step" style="display: none">
              <div class="card-header font-weight-bold" style="background-color:#dfdfdf">
                <i class="fa fa-step-forward" style="margin-right:10px"></i><strong>Step 2</strong>
                <div>
                  <label >Delivery Information</label>
                </div>
              </div>
              <div class="mb-3">
                <h5 class="card-title font-weight-bold" style="margin-top:20px;color:#519bfd;">Delivery Information</h5>
              </div>
              <div class="form-group row mb-3">
                
                <div class="col-lg-6 col-md-12 col-sm-12">
                 <div class="col-lg-12 mb-3">
                    
                    <label for="company_name">Company Name<b style="color: #dc3545;">*</b></label>
                    <input type="text" name="company_name" class="form-control" id="company_name" required>
                    <div class="invalid-feedback">This field is required</div>
                  </div>

                  <div class="col-lg-12 mb-3">
                    
                    <label for="address">Address name<b style="color: #dc3545;">*</b></label>
                    <input type="text" name="address" class="form-control" id="address" required>
                    <div class="invalid-feedback">This field is required</div>
                  </div>
                  <div class="col-lg-12 mb-3">
                    
                    <label for="delivery_city">Delivery City<b style="color: #dc3545;">*</b></label>
                    <input type="text" name="delivery_city" class="form-control" id="delivery_city" required>
                    <div class="invalid-feedback">This field is required</div>
                  </div>
                  <div class="col-lg-12 mb-3">
                    
                    <label for="instruction">Instruction<b style="color: #dc3545;">*</b></label>
                    <textarea class="form-control" id="instruction" name="instruction" cols="5" rows="5">
                    
                    </textarea>
                    <div class="invalid-feedback">This field is required</div>
                  </div>
                  
                </div>
                <div class="col-lg-6">
                  <div id="map" style="width:100%;height:300px;"></div>
                </div>
                
              </div>
            </div>
            <div class="card-body p-5 step" style="display: none">
              <div class="card-header font-weight-bold" style="background-color:#dfdfdf">
                <i class="fa fa-step-forward" style="margin-right:10px"></i><strong>Step 3</strong>
                <div>
                  <label >Qualification Criteria</label>
                </div>
              </div>
              <div class="mb-3">
                <h5 class="card-title font-weight-bold" style="margin-top:20px;color:#519bfd;">Qualification Criteria</h5>
              </div>
              <div class="form-group row mb-3">
                
                <div class="col-lg-8">
                  <div class="col-lg-12 col-md-12 mb-3">
                    
                    <label for="categories">Categories<b style="color: #dc3545;">*</b></label>
                    <input type="text" name="categories" class="form-control" id="categories" required>
                    <div class="invalid-feedback">This field is required</div>
                  </div>
                  <div class="col-lg-12 col-md-12 mb-3">
                    
                    <label for="bidder_location">Bidders Location<b style="color: #dc3545;">*</b></label>
                    <input type="text" name="bidder_location" class="form-control" id="bidder_location" required>
                    <div class="invalid-feedback">This field is required</div>
                  </div>
                  
                  
                </div>
                
                
              </div>
            </div>
            <div class="card-body p-5 step" style="display: none">
              <div class="card-header font-weight-bold" style="background-color:#dfdfdf">
                <i class="fa fa-step-forward" style="margin-right:10px"></i><strong>Step 4</strong>
                <div>
                  <label>Scope of Work</label>
                </div>
              </div>
              <div class="mb-3">
                <h5 class="card-title font-weight-bold" style="margin-top:20px;color:#519bfd;">Scope of Work</h5>
              </div>
              <div class="form-group row mb-3">
                
                <div class="col-lg-8">
                  <div class="col-lg-12 col-md-12 mb-3">
                    
                    <label for="estimate_budget">Estimated Budegt<b style="color: #dc3545;">*</b></label>
                    <input type="text" name="estimate_budget" class="form-control" id="estimate_budget" required>
                    <div class="invalid-feedback">This field is required</div>
                  </div>
                  <div class="col-lg-12 col-md-12">
                    <label>All registered business can view.</label>
                  </div>
                  <div class="col-lg-12 col-md-12 mb-3">
                    
                    <label for="document_name">Document name<b style="color: #dc3545;">*</b></label>
                    <input type="text" name="document_name" class="form-control" id="document_name" required>
                    <div class="invalid-feedback">This field is required</div>
                  </div>
                  <div class="col-lg-12 col-md-12 mb-3">
                    
                    <label for="document_description">Document Description<b style="color: #dc3545;">*</b></label>
                    <input type="text" name="document_description" class="form-control" id="document_description" required>
                    <div class="invalid-feedback">This field is required</div>
                  </div>
                  <div class="col-lg-12 col-md-12 mb-3">
                    
                    <label for="document">Attachments<b style="color: #dc3545;">*</b></label>
                    <input type="file" name="document" class="form-control" id="document" required>
                    <div class="invalid-feedback">This field is required</div>
                  </div>
                  <div class="col-lg-12 col-md-12 mb-3">
                    <label><strong>How do you want to receive quotation?</strong> </label>
                  </div>
                  <div class="col-lg-12 col-md-12 mb-3">
                    <input type="radio" id="combined" name="fav_language" value="combined">
                    <label for="combined" class="combined" >Combined in one proposal ( Technical specification & Commerical quotation )</label>
                  </div>
                  <div class="col-lg-12 col-md-12 mb-3">
                    <input type="radio" id="seperate" name="fav_language" value="seperate">
                    <label for="seperate" class="seperate">Separated into 2 proposal ( Techinal - Commerical ) where the commerical <br> proposal will be viewable after viewing the technical one.</label>
                  </div>
                  
                  
                </div>
                
                
              </div>
            </div>
            <div class="card-body p-5 step" style="display: none">
              <div class="card-header font-weight-bold" style="background-color:#dfdfdf">
                <i class="fa fa-step-forward" style="margin-right:10px"></i><strong>Step 5</strong>
                <div>
                  <label>Contact Information</label>
                </div>
              </div>
              <div class="mb-3">
                <h5 class="card-title font-weight-bold" style="margin-top:20px;color:#519bfd;">Contact Information</h5>
              </div>
              <div class="form-group row mb-3">
                
                <div class="col-lg-10">
                  <div class="col-lg-12 mb-3">
                    
                    <label for="contact_information" style="margin-bottom: 10px;">This contact information will only be visible to the awarded business</label>
                    <input type="file" name="contact_information_logo" class="form-control" required>
                  
                  </div>


                  <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12 mb-1">
                      <div class="col-lg-12">
                        <label for="name">Name</label>
                        <input type="text" id="name" name="name" class="form-control">
                      </div>
                      
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 mb-1">
                      <div class="col-lg-12">
                        <label>Position</label>
                        <input type="text" name="position" class="form-control">
                      </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 mb-1">
                      <div class="col-lg-12">
                        <label>Email</label>
                        <input type="email" name="email" class="form-control">
                      </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 mb-1">
                      <div class="col-lg-12">
                        <label>Phone</label>
                        <input type="number" name="phone" class="form-control">
                      </div>
                    </div>
                    
                  </div>

                  
                  
                  
                  
                  
                  
                  
                  
                  
                </div>
                
                
              </div>
            </div>
            <div class="card-footer">
              <div class="row text-center mt-3">
            <div class="col-lg-12">
              
              <button class="action back btn btn-sm btn-outline-warning back-button " style="display: none">Back</button>
              <button class="action next  next-button " disabled="">Move Next</button>
              <button type="submit" class="action submit btn btn-sm btn-outline-success " style="display: none;padding: 5px 25px;">Submit</button>
            </div>
          </div>
            </div>
          </div>
          

        </div>
      </div>
      
      </form>
      
    </section>
    <section class="mb-5 mt-5">
      <div class="container brief-container mb-5">
        <div class="col-lg-12">
          <h3 class="text-center" style="color:#519bfd">Brief Overview of the Services</h3>
        </div>
        <div class="col-lg-12 mt-3">
          <p class="text-center">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
            consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
            cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
          proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>
        </div>
      </div>
    </section>



 <section class="section-top">
      <div class="container text-center">
      <div class="row mb-5">
        <div class="col-lg-12">
      <iframe class="video-width" src="https://www.youtube.com/embed/sdw0GQB5lJE" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </div>
      </div>  
      </div>
      
      
    </section>




    
    <section class="mt-5">
      <div class="container last-picture-container">
        <div class="row text-center">
          <div class="col-lg-2 col-md-4 col-sm-4">
            <img src="<?php echo e(asset('asset/images/2 (5).png')); ?>" class="our-top-partner-images">
          </div>
          <div class="col-lg-2 col-md-4 col-sm-4">
            <img src="<?php echo e(asset('asset/images/2 (4).png')); ?>" class="our-top-partner-images"  >
          </div>
          <div class="col-lg-2 col-md-4 col-sm-4">
            <img src="<?php echo e(asset('asset/images/2 (1).png')); ?>" class="our-top-partner-images our-top-partner-images-padding"  >
          </div>
          <div class="col-lg-2 col-md-4 col-sm-4">
            <img src="<?php echo e(asset('asset/images/2 (5).png')); ?>" class="our-top-partner-images"  >
          </div>
          <div class="col-lg-2 col-md-4 col-sm-4">
            <img src="<?php echo e(asset('asset/images/2 (3).png')); ?>" class="our-top-partner-images college-excellence">
          </div>
          <div class="col-lg-2 col-md-4 col-sm-4">
            <img src="<?php echo e(asset('asset/images/2 (2).png')); ?>"  class="last-image-width">
            
          </div>
        </div>
        <div class="row mt-5 mb-5 text-center">
          <div class="col-lg-12">
            <a href="" class="btn btn-primary see-more">Show All</a>
          </div>
          
        </div>
        
      </div>
      
    </section>
    <?php echo $__env->make('frontendtemplate.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js'></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCvzUOgLYwHoBZGtk4Z_lrPphPR1nxTilo&callback=initMap">
    </script>
    <script type="text/javascript">
    function initMap() {
    var dumbo = {lat: 33.6844, lng:73.0479};
    var mapOptions = {
    center: dumbo,
    zoom: 10
    };
    var googlemap = new google.maps.Map(document.getElementById("map"), mapOptions);
    }
    </script>
    <script type="text/javascript">
    $(".radio-group .radio").on("click", function () {
    $(".selected .fa").removeClass("fa-check");
    $(".radio").removeClass("selected");
    $(this).addClass("selected");
    if ($("#suser").hasClass("selected") == true) {
    $(".next").prop("disabled", true);
    } else {
    setFormFields(false);
    $(".next").prop("disabled", false);
    }
    });
    var step = 1;
    $(document).ready(function () { stepProgress(step); });
    $(".next").on("click", function () {
    var nextstep = false;
    if (step == 2) {
    nextstep = checkForm("userinfo");
    } else {
    nextstep = true;
    }
    if (nextstep == true) {
    if (step < $(".step").length) {
    $(".step").show();
    $(".step").not(":eq(" + step++ + ")").hide();
    stepProgress(step);
    }
    hideButtons(step);
    }
    });
    // ON CLICK BACK BUTTON
    $(".back").on("click", function () {
    if (step > 1) {
    step = step - 2;
    $(".next").trigger("click");
    }
    hideButtons(step);
    });
    // CALCULATE PROGRESS BAR
    stepProgress = function (currstep) {
    var percent = parseFloat(100 / $(".step").length) * currstep;
    percent = percent.toFixed();
    $(".progress-bar")
    .css("width", percent + "%")
    .html(percent + "%");
    };
    // DISPLAY AND HIDE "NEXT", "BACK" AND "SUMBIT" BUTTONS
    hideButtons = function (step) {
    var limit = parseInt($(".step").length);
    $(".action").hide();
    if (step < limit) {
    $(".next").show();
    }
    if (step > 1) {
    $(".back").show();
    }
    if (step == limit) {
    $(".next").hide();
    $(".submit").show();
    }
    };
    function setFormFields(id) {
    if (id != false) {
    // FILL STEP 2 FORM FIELDS
    d = data.find(x => x.id === id);
    $('#fname').val(d.fname);
    $('#lname').val(d.lname);
    $('#team').val(d.team);
    $('#address').val(d.address);
    $('#tel').val(d.tel);
    }
    }
    function checkForm(val) {
    // CHECK IF ALL "REQUIRED" FIELD ALL FILLED IN
    var valid = true;
    $("#" + val + " input:required").each(function () {
    if ($(this).val() === "") {
    $(this).addClass("is-invalid");
    valid = false;
    } else {
    $(this).removeClass("is-invalid");
    }
    });
    return valid;
    }
    </script>

<script type="text/javascript">
$(document).ready(function(){
    $('input[type="radio"]').click(function(){
        var inputValue = $(this).attr("value");
        var targetBox = $("." + inputValue);
        $(".box").not(targetBox).hide();
        $(targetBox).show();
    });
});
</script>

<script type="text/javascript">
  $(function(){
    var dtToday = new Date();
    
    var month = dtToday.getMonth() + 1;
    var day = dtToday.getDate();
    var year = dtToday.getFullYear();
    if(month < 10)
        month = '0' + month.toString();
    if(day < 10)
        day = '0' + day.toString();
    
    var minDate= year + '-' + month + '-' + day;
    
    $('.due_date_validation').attr('min', minDate);
});
</script>
  </body>
</html><?php /**PATH F:\xampp\htdocs\biddingmanagement\biddingmanagement\resources\views/userpages/create_opportunity.blade.php ENDPATH**/ ?>