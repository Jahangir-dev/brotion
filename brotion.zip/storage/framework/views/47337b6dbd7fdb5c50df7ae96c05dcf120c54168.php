
<?php $__env->startSection('content'); ?>

<div class="main-content">
        <section class="section">
          <div class="section-header">
						<div class="row">
							<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
								<div class="section-header-breadcrumb-content">
									<h1>Add New Province</h1>
								</div>
							</div>
							<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
								<div class="section-header-breadcrumb-chart float-right">
								</div>
							</div>
						</div>
          </div>
        <form method="post" action="<?php echo e(route('admin-province-save')); ?>">
          <?php echo csrf_field(); ?>
  
          <div class="row">
            <div class="col-lg-12">
              <div class="col-lg-12">
                <div class="card">
                  <div class="card-body">
                    <div class="col-lg-12">
                      <label><strong>Province  Name</strong></label>
                      <input type="text" name="name"  class="form-control" required>
                    </div>

                    <div class="col-lg-12 mt-3">
                      <a href="<?php echo e(route('province-list')); ?>" class="btn btn-dark" style="float:right">Exit</a>
                      <button type="submit" class="btn btn-primary" style="float:right;margin-right: 20px;">Save</button>

                      
                    </div>
                    
                  </div>
                  
                </div>
              </div>
              
            </div>
            
          </div>
 </form>
         

          

      </section>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.partials.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/r0mm6f8xfmww/public_html/resources/views/admin/add_new_province.blade.php ENDPATH**/ ?>