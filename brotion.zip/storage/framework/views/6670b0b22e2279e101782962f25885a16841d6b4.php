<footer class="main-footer">
        <div class="footer-left">
          Copyright &copy; 2020 <div class="bullet"></div> Design By <a href="#">Snkthemes</a>
        </div>
        <div class="footer-right">
        </div>
      </footer>
    
  <!-- General JS Scripts -->
  <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>
  <!-- JS Libraies -->
  <script src="<?php echo e(asset('assets/bundles/echart/echarts.js')); ?>"></script>
  
  <script src="<?php echo e(asset('assets/bundles/chartjs/chart.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/bundles/apexcharts/apexcharts.min.js')); ?>"></script>
  <!-- Page Specific JS File -->
  <script src="<?php echo e(asset('assets/js/page/index.js')); ?>"></script>
  <!-- Template JS File -->
  <script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/bundles/jquery.sparkline.min.js')); ?>"></script>
  
</body>


<!-- Mirrored from radixtouch.in/templates/snkthemes/grexsan/source/light/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 30 Dec 2020 17:20:55 GMT -->
</html><?php /**PATH F:\xampp\htdocs\biddingmanagement\biddingmanagement\resources\views/template/partials/footer.blade.php ENDPATH**/ ?>