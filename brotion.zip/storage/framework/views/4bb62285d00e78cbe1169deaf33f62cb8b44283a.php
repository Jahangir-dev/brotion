 
    <section class="box-shadow" >
      <ul class="bottomnav">
        
        <div class="logo"><li ><img src="<?php echo e(asset('asset/images/logo.png')); ?>" class="logo"><a href=""></a></li></div>
        
        
        <?php if(Auth::check()): ?>
        <li ><a href="<?php echo e(route('opportunity-management')); ?>">Opportunity Management</a></li>
        <li ><a href="<?php echo e(route('bid-management')); ?>"  >Bid Management</a></li>
        <li><a href="<?php echo e(route('user-business')); ?>">Business</a></li>
        <?php endif; ?>
        <li><a href="<?php echo e(route('market-place')); ?>">MarketPlace</a></li>
        <li><a href="<?php echo e(route('welcome')); ?>">Reviews</a></li>

      </ul>
    </section><?php /**PATH F:\xampp\htdocs\biddingmanagement\biddingmanagement\resources\views/frontendtemplate/navbar.blade.php ENDPATH**/ ?>