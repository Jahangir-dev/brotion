
    <section class="box-shadow  " >
      <ul  class="bottomnav ">


        <li>  <?php if(Auth::check()): ?>
            <div class="dropdown" style="float:right;">
                <span><img class="img-fluid" src="<?php echo e(asset('asset/images/Icon awesome-user-alt.png')); ?>" style="margin-right: 10px;"></span>
                <span><img class="img-fluid" src="<?php echo e(asset('asset/images/Polygon 1.png')); ?>" style=""></span>
                <div class="dropdown-content" style="margin-left:-35px">
                  <div><a href="<?php echo e(route('user-business')); ?>">Profile</a></div>
                  
                  <div> <a href="<?php echo e(route('logout')); ?>">Logout</a></div>

                </div>
              </div>

            <?php else: ?>
            <div class="dropdown" style="float:right;">
                <span><img class="img-fluid" src="<?php echo e(asset('asset/images/Icon awesome-user-alt.png')); ?>" style="margin-right: 10px;"></span>
                <span><img class="img-fluid" src="<?php echo e(asset('asset/images/Polygon 1.png')); ?>" style=""></span>
                <div class="dropdown-content" style="margin-left:-35px">
                    <a href="<?php echo e(route('register')); ?>">Join Us</a><br>
                    <a href="<?php echo e(route('login')); ?>">Login</a>

                </div>
              </div>

            <?php endif; ?></li>







        <div class="logo"><li ><img src="<?php echo e(asset('asset/images/newlogo.png')); ?>" class="logo"><a href=""></a></li></div>


        <?php if(Auth::check()): ?>
        <li ><a href="<?php echo e(route('opportunity-management')); ?>">My Tender</a></li>
        <li ><a href="<?php echo e(route('bid-management')); ?>">My Bids</a></li>
       <!--  <li><a href="<?php echo e(route('user-business')); ?>">Profile</a></li> -->
        <?php endif; ?>
        <li><a href="<?php echo e(route('market-place')); ?>">MarketPlace</a></li>
        <li><a href="<?php echo e(route('welcome')); ?>">Home</a></li>

      </ul>

    </section>

<?php /**PATH /home/r0mm6f8xfmww/staging.brotions.com/resources/views/frontendtemplate/navbar.blade.php ENDPATH**/ ?>