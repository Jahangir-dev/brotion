
<?php $__env->startSection('content'); ?>

<div class="main-content">
        <section class="section">
          <div class="section-header">
						<div class="row">
							<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
								<div class="section-header-breadcrumb-content">
									<h1>Category List</h1>
								</div>
							</div>
							<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
								<div class="section-header-breadcrumb-chart float-right">
									
								
									
								</div>
							</div>
						</div>
          </div>


           <div class="row">
            <div class="col-lg-12 mb-3">
              <a href="<?php echo e(route('add-new-opp-category')); ?>" class="btn btn-primary" style="float:right;">Add Category</a>
              
            </div>
             
           </div>
          <div class="row">
              
              <div class="col-12 col-md-12 col-lg-12">
                <div class="card">
                  <div class="card-header">
                    <h4></h4>
                  </div>
                  <div class="card-body">
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th scope="col">#</th>
                          <th scope="col">Name</th>
                          <th colspan="2">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $i=1
                        ?>
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($i++); ?></td>
                          <td><?php echo e($c->name); ?></td>
                          <td>
                            <a href="<?php echo e(route('opp-category-edit',['id'=>$c->id])); ?>" class="btn btn-primary">Edit</a>
                              <a href="<?php echo e(route('opp-category-delete',['id'=>$c->id])); ?>" class="btn btn-dark">Delete</a>
                          </td>
                          
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                      
                      
                    </table>
                    <?php echo e($category->links()); ?>

                    
                  </div>
                </div>
                
                
              </div>
             
            </div>

      </section>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.partials.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\brotion\resources\views/admin/opportunity_category_list.blade.php ENDPATH**/ ?>