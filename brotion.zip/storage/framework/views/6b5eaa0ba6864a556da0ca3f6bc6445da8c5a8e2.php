<section style="margin-top:5rem">
      <div class="footer-image">
        <div class="container textcenter">
          <div class="row pt-5">
            <div class="col-lg-3"></div>
            <div class="col-lg-3"></div>
            <div class="col-lg-3"></div>
            <div class="col-lg-3">
              <h1 style="color:white;">Services</h1>
            </div>
            
          </div>
          <div class="row">
            <div class="col-lg-3 col-md-12 col-sm-12 mt-5">
              <div class="col-lg-12 ">
                <img src="<?php echo e(asset('asset/images/logo.png')); ?>">
              </div>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-4 mt-5">
              <div class="row">
                <div class="col-lg-12 ">
                  <label style="color:white;">Opportunity</label>
                </div>
                <div class="col-lg-12 ">
                  <label style="color:white;">Made in Saudi Arabia</label>
                </div>
                <div class="col-lg-12 ">
                  <label style="color:white;">Increased</label>
                </div>
                <div class="col-lg-12">
                  <label style="color:white;">Trader</label>
                </div>
                
              </div>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-4 mt-5">
              <div class="row">
                <div class="col-lg-12">
                  <label style="color:white;">Opportunity</label>
                </div>
                <div class="col-lg-12">
                  <label style="color:white;">Made in Saudi Arabia</label>
                </div>
                <div class="col-lg-12">
                  <label style="color:white;">Increased</label>
                </div>
                <div class="col-lg-12">
                  <label style="color:white;">Trader</label>
                </div>
                
              </div>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-4 mt-5">
              <div class="row">
                <div class="col-lg-12 ">
                  <label style="color:white;">Opportunity</label>
                </div>
                <div class="col-lg-12 ">
                  <label style="color:white;">Made in Saudi Arabia</label>
                </div>
                <div class="col-lg-12 ">
                  <label style="color:white;">Increased</label>
                </div>
                <div class="col-lg-12 ">
                  <label style="color:white;">Trader</label>
                </div>
                
              </div>
            </div>
            
          </div>
        </div>
        <div class="row mt-5">
          <div class="col-lg-12">
            <hr style="height: 2px; color: white;">
          </div>
          
        </div>
        <div class="container">
          <div class="row" >
            <div class="col-lg-3">
              
            </div>
            <div class="col-lg-3">
              
            </div>
            <div class="col-lg-3">
              
            </div>
            <div class="col-lg-3 text-center">
              <div class="d-inline">
                <img src="<?php echo e(asset('asset/images/facebook.png')); ?>" class="footer-image-space">
              </div>
              <div class="d-inline">
                <img src="<?php echo e(asset('asset/images/twitter.png')); ?>" class="footer-image-space">
              </div>
              <div class="d-inline">
                <img src="<?php echo e(asset('asset/images/insta.png')); ?>" class="footer-image-space">
              </div>
              <div class="d-inline">
                <img src="<?php echo e(asset('asset/images/linkedin.png')); ?>" class="footer-image-space">
              </div>
              <div class="d-inline">
                <img src="<?php echo e(asset('asset/images/youtube.png')); ?>" class="footer-image-space">
              </div>
            </div>
            
          </div>
        </div>
        
        
      </div>
      
    </section>
       <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\biddingmanagement\biddingmanagement\resources\views/frontendtemplate/footer.blade.php ENDPATH**/ ?>