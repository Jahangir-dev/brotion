<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/css/bidmanagement2.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Bid Mangement</title>
  </head>
  <body>


    <?php echo $__env->make('frontendtemplate.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="mb-5">
        <div class=" container-fluid  text-center showmarket ">
        <div class="row">

            <div class="col-lg-6 col-md-6 col-sm-6 pt-3  d-block ">
             <h1 >Brief Overview of the Services</h1>
             <p>In publishing and graphic design, Lorem ipsum is a placeholder
                text commonly used to demonstrate the visual form of a document
                or a typeface without</p>
             <button  class="btn text-white buttoncolor">Open Opportunities</button>
           </div>
        </div>
        </div>
      </section>





    <section class="mt-3">
      <div class="container">
        <div class="row">



        </div>
        <div class="row mt-3 mb-5 card-spaces">


          

        </div>
        <div class="row mt-5 mb-5">

          <div class="col-lg-3 col-md-4 col-sm-4 category">
            <form method="get" action="<?php echo e(route('bid-management')); ?>">
              <select class="form-select" style="background-color: #519bfd;
                color: white;" name="category" onchange="this.form.submit()">
                <option value="<?php echo e(Null); ?>"> Category</option>
                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </form>

          </div>
          <div class="col-lg-5 col-md-4 col-sm-4 search">
            <form action="<?php echo e(route('bid-management')); ?>" method="get" role="search" style="margin-bottom:20px;">
              <div class="input-group">
                <input class="form-control bg-white text-white" name="opp_title" style="border-radius:5px; color: #d7d7d7;"  type="search" value="<?php echo e(isset($request->opp_title)?$request->opp_title:''); ?>" id="example-search-input" placeholder="Search By Opportunity Title">
                <span class="input-group-append">
                </span>
              </div>
            </form>
          </div>
          <div class="col-lg-4 col-md-4 col-sm-4 sort-by-row">
            <form action="<?php echo e(route('bid-management')); ?>" method="get" >
            <select class="form-select sort-by" name="sortby" style="border:1px solid #519bfd;color: #519bfd;" onchange="this.form.submit()">
              <option value="<?php echo e(Null); ?>">Sort By</option>
              <option value="date">Date</option>
            </select>
            </form>
          </div>

        </div>
      </div>

    </section>
    <section class="mt-5 mb-5">
      <div class="container">
        <div class="row">



          <div class="col-lg-3 col-md-5 col-sm-12">
            <div class="card bottom-card">
              <div class="card-body">
                <form action="<?php echo e(route('market-place')); ?>" method="get" id="qualifiaction" role="search" style="margin-bottom:20px;">
                  <div class="col-lg-12 mb-3">
                    <h6><strong>Filter by:</strong></h6>
                  </div>
                  <div class="col-lg-12">
                    <input type="checkbox" id="all" class="check-box qualifiactionclass" name="data" value="all">
                    <label for="all" class="label-card"> Approved</label>
                  </div>
                  <div class="col-lg-12">
                    <input type="checkbox" id="yes" class="check-box qualifiactionclass" name="data" value="yes">
                    <label for="yes" class="label-card"> pending </label>
                  </div>
                  <div class="col-lg-12">
                    <input type="checkbox" id="no" class="check-box qualifiactionclass" name="data" value="no">
                    <label for="no" class="label-card">Lost</label>
                  </div>
                </form>
                <div class="col-lg-12 mt-5 mb-5">
                  <hr style="height:2px;color:black;">
                </div>



                <form action="<?php echo e(route('bid-management')); ?>" method="get" id="opptype" role="search" style="margin-bottom:20px;">
                  <div class="col-lg-12 mb-3">
                    
                  </div>

                  <div class="col-lg-12">
                    
                  </div>
                  <div class="col-lg-12">
                    
                  </div>
                </form>

              </div>

            </div>

          </div>
          <div class="col-lg-9 col-md-7 col-sm-12">
            <div class="row card-row-width">
              <?php $__currentLoopData = $opportunity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <?php if(isset($o->opt_not_required)): ?>
              <?php else: ?>
              <div class="col-lg-6 col-md-12 mb-3">

                <div class="card bottomcard">
                  <div class="card-body">
                    <div class="col d-inline" style="margin-left: 10px;">
                      <label class="avaiable">Avaiable</label>
                    </div>
                    <div class="col d-inline">
                      <label><?php echo e($o->opp_count->count()); ?></label>
                    </div>
                    <div class="col d-inline">
                      <i class="fa fa-eye" aria-hidden="true"></i>
                    </div>
                    <div class="col d-inline">
                      <a href="<?php echo e(route('opp-not-required',['id'=>$o->opp_id])); ?>" style="text-decoration:none" class="bottom-card-input text-center" placeholder="Not Required">Hide</a>

                    </div>
                    <div class="col d-inline">
                      <i class="fa fa-bell" aria-hidden="true" style="color:#519bfd"></i>
                    </div>
                    <div class="col d-inline">
                      <i class="fa fa-share" aria-hidden="true" style="color:#519bfd"></i>
                    </div>
                    <a href="<?php echo e(route('bidding-opportunity-details',['id'=>$o->id,'opp_id'=>$o->opp_id])); ?>" style="text-decoration:none">
                      <div class="row mt-3">
                        <div class="col-lg-12">
                          <label style="color:#519bfd"><strong><?php echo e(isset($o->opp_detail->user_opp_title)?$o->opp_detail->user_opp_title->opp_title:''); ?></strong></label>
                        </div>

                      </div>
                      <div class="row mt-3">
                        <div class="col-lg-12 mb-1">
                          <label class="label-font"><?php echo e(isset($o->opp_detail->opp_category)?$o->opp_detail->opp_category->name:''); ?></label>
                        </div>
                        <div class="col-lg-12 mb-1">
                          <label class="label-font"><?php echo e(isset($o->opp_detail)?$o->opp_detail->bidder_location:''); ?> </label>
                        </div>
                        <div class="col-lg-12 mb-1">
                          <label class="label-font"><?php echo e(isset($o->user_detail)?$o->user_detail->company_name:''); ?></label>
                        </div>
                        <div class="col-lg-12 mb-1">
                          <label class="label-font"><?php echo e(isset($o->opp_detail->user)?$o->opp_detail->user->email:''); ?> </label>
                        </div>

                        <div class="col-lg-12">
                          <hr style="color:#006eff;height: 2px;">
                        </div>

                      </div>
                      <div class="row">
                        <div class="col">
                          <img src="<?php echo e(isset($o->user_detail)?$o->user_detail->company_logo:''); ?>" class="bottom-pic">
                        </div>
                        <div class="col">
                          <label style="float:right; color: #006eff;"><strong><?php echo e($o->due_date); ?></strong></label>

                        </div>
                      </div>
                      <div class="row day-left">
                        <div class="col-lg-12">
                          <label>Days Left</label>
                        </div>
                      </div>
                    </div>

                  </div>
                </a>
              </div>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            </div>
          </div>
        </div>
      </div>

    </section>
    <section class="mt-3 mb-3">
      <div class="container text-center">
        <div class="row">
          <div class="col-lg-12">
            <div class="d-flex">
              <div class="mx-auto">
                <?php echo e($opportunity->links()); ?>

              </div>
            </div>
          </div>

        </div>
      </div>

    </section>
    
    <?php echo $__env->make('frontendtemplate.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>

    <script type="text/javascript">
    $(function(){
    $('.qualifiactionclass').on('change',function(){
    $('#qualifiaction').submit();
    });
    });
    </script>
    <script type="text/javascript">
    $(function(){
    $('.opptype').on('change',function(){
    $('#opptype').submit();
    });
    });
    </script>
    <script type="text/javascript">
        $(function(){
         $('.sortby').on('change',function(){
            $('#sort').submit();
            });
        });
    </script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\app\resources\views/userpages/bid_management.blade.php ENDPATH**/ ?>